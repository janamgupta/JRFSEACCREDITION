package com.tweetApp.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweetApp.Model.Register;

public interface UserRepository extends MongoRepository<Register,String> {
	
	Register findByEmail(String email);
	
	Register findByLoginId(String loginId);
	

}
