package com.tweetApp.Service;

import java.util.List;

import com.tweetApp.DTO.ReplyDTO;
import com.tweetApp.DTO.ReplyResponseDTO;
import com.tweetApp.DTO.TweetRequestDTO;
import com.tweetApp.DTO.TweetResponseDTO;

public interface TweetService {
	
	String postTweet(TweetRequestDTO tweerRequest);
	
	List<TweetResponseDTO> getAllTweets();

	String postReply(ReplyDTO replyDTO);

	String deleteTweet(int tweetId);
	
	List<ReplyResponseDTO> getReplies(int tweetId);
	
	String updateLikes(int tweetId);
	
	List<TweetResponseDTO> getUserTweet(String loginId);
}
