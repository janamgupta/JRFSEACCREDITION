package com.tweetApp.ServiceImpl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetApp.DTO.ReplyDTO;
import com.tweetApp.DTO.ReplyResponseDTO;
import com.tweetApp.DTO.TweetRequestDTO;
import com.tweetApp.DTO.TweetResponseDTO;
import com.tweetApp.Model.Register;
import com.tweetApp.Model.Reply;
import com.tweetApp.Model.Tweet;
import com.tweetApp.Repository.ReplyRepository;
import com.tweetApp.Repository.TweetRepository;
import com.tweetApp.Repository.UserRepository;
import com.tweetApp.Service.NextSequenceSerive;
import com.tweetApp.Service.TweetService;

@Service
public class TweetServiceImpl implements TweetService {

	@Autowired
	TweetRepository tweetRepo;

	@Autowired
	UserRepository userRepo;

	@Autowired
	ReplyRepository replyRepo;

	@Autowired
	TweetService tweetService;
	
	@Autowired
	NextSequenceSerive nextSequenceService;
	
	@Override
	public String postTweet(TweetRequestDTO tweetRequest) {
		// TODO Auto-generated method stub
		Tweet tweets = convertDTOToEntity(tweetRequest);
		tweetRepo.save(tweets);
		String msg = null;
		if (tweets != null) {
			msg = "Success";
			return msg;
		} else {
			msg = "Internal Server Error Occured";
		}
		return msg;
	}

	private Tweet convertDTOToEntity(TweetRequestDTO tweetRequest) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();

		Tweet tweets = new Tweet();
		
		tweets.setId(nextSequenceService.getNextSequence("customSequences"));
		tweets.setTweetDescription(tweetRequest.getTweetDesc());
		tweets.setTweetTag(tweetRequest.getTweetTag());
		tweets.setDate(dtf.format(now));
		tweets.setEmail(tweetRequest.getEmailId());
		tweets.setLoginId(tweetRequest.getLoginId());
		tweets.setLikes(0);
		tweets.setReply(0);
		return tweets;
	}

	@Override
	public List<TweetResponseDTO> getAllTweets() {
		// TODO Auto-generated method stub

		List<TweetResponseDTO> tweetResponseDTOList = new ArrayList<>();
		List<Tweet> tweetList = tweetRepo.findAll();
		tweetList.stream().forEach(tweet -> {
			TweetResponseDTO tweetResponseDTO = new TweetResponseDTO();
			Register userInfo = userRepo.findByLoginId(tweet.getLoginId());
			tweetResponseDTO.setTweetDesc(tweet.getTweetDescription());
			tweetResponseDTO.setName(userInfo.getFirstName()+" "+userInfo.getLastName());
			tweetResponseDTO.setLikes(tweet.getLikes());
			tweetResponseDTO.setLoginId(tweet.getLoginId());
			tweetResponseDTO.setHashTag(tweet.getTweetTag());
			tweetResponseDTO.setTweetId(tweet.getId());
			tweetResponseDTO.setDate(tweet.getDate());
			List<Reply> replyList = replyRepo.findByTweetId(tweet.getId());
			tweetResponseDTO.setReplies(replyList.size());;
			tweetResponseDTOList.add(tweetResponseDTO);
		});

		return tweetResponseDTOList;

	}

	@Override
	public String postReply(ReplyDTO replyDTO) {
		// TODO Auto-generated method stub
		Reply reply = converttDTOToReplyEntity(replyDTO);
		reply = replyRepo.save(reply);
		String msg = null;
		if (reply != null) {
			msg = "Success";
			return msg;
		} else {
			msg = "Internal Server Error Occured";
		}
		return msg;
	}

	public Reply converttDTOToReplyEntity(ReplyDTO replyDTO) {
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();

		Reply reply = new Reply();
		reply.setLoginId(replyDTO.getLoginId());
		reply.setTweetId(replyDTO.getTweetId());
		reply.setReplyDesc(replyDTO.getReplyDesc());
		reply.setDate(dtf.format(now));
		reply.setReplyTo(replyDTO.getReplyTo());
		return reply;
	}

	@Override
	public String deleteTweet(int tweetId) {
		// TODO Auto-generated method stub
		Tweet tweet = tweetRepo.deleteById(tweetId);
		if(tweet == null) {
			replyRepo.deleteByTweetId(tweetId);
			return "success";
		}
		return "failed";
	}

	@Override
	public List<ReplyResponseDTO> getReplies(int tweetId) {
		List<ReplyResponseDTO> repliesList = new ArrayList<ReplyResponseDTO>();
		List<Reply> replies = replyRepo.findByTweetId(tweetId);
		replies.stream().forEach(reply ->{
			ReplyResponseDTO replyDTO = new ReplyResponseDTO();
			replyDTO.setReplyDesc(reply.getReplyDesc());
			replyDTO.setTweetId(reply.getTweetId());
			replyDTO.setDate(reply.getDate());
			Register register = userRepo.findByLoginId(reply.getLoginId());
			replyDTO.setName(register.getFirstName()+" "+register.getLastName());
			replyDTO.setLoginId(reply.getLoginId());
			replyDTO.setReplyTo(reply.getReplyTo());
			repliesList.add(replyDTO);	
		});
		return repliesList;
	}

	@Override
	public String updateLikes(int tweetId) {
		Optional<Tweet> OptionalTweet = tweetRepo.findById(tweetId);
		if(OptionalTweet.isPresent()) {
			Tweet tweet = new Tweet();
			tweet = OptionalTweet.get();
			tweet.setLikes(tweet.getLikes() + 1);
			tweet = tweetRepo.save(tweet);
			if(tweet != null) {
				return "success";
			} else {
				return "failed";
			}
		} 
		return "failed";
	}

	@Override
	public List<TweetResponseDTO> getUserTweet(String loginId) {
		List<TweetResponseDTO> tweetResponseDTOList = new ArrayList<>();
		List<Tweet> tweetList = tweetRepo.findByLoginId(loginId);
		tweetList.stream().forEach(tweet -> {
			TweetResponseDTO tweetResponseDTO = new TweetResponseDTO();
			Register userInfo = userRepo.findByLoginId(tweet.getLoginId());
			tweetResponseDTO.setTweetDesc(tweet.getTweetDescription());
			tweetResponseDTO.setName(userInfo.getFirstName()+" "+userInfo.getLastName());
			tweetResponseDTO.setLikes(tweet.getLikes());
			tweetResponseDTO.setLoginId(tweet.getLoginId());
			tweetResponseDTO.setHashTag(tweet.getTweetTag());
			tweetResponseDTO.setTweetId(tweet.getId());
			tweetResponseDTO.setDate(tweet.getDate());
			List<Reply> replyList = replyRepo.findByTweetId(tweet.getId());
			tweetResponseDTO.setReplies(replyList.size());;
			tweetResponseDTOList.add(tweetResponseDTO);
		});

		return tweetResponseDTOList;
	}
}
