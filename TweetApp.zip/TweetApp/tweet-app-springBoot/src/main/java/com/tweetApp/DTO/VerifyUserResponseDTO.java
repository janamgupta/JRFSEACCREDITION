package com.tweetApp.DTO;

public class VerifyUserResponseDTO {
	
	String email;
	String successMessage;
	String errorMessage;
	
	public VerifyUserResponseDTO() {
		// TODO Auto-generated constructor stub
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "VerifyUserResponseDTO [email=" + email + ", successMessage=" + successMessage + "]";
	}
}
