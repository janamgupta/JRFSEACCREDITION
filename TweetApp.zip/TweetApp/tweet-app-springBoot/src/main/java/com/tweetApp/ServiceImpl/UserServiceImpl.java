package com.tweetApp.ServiceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetApp.DTO.ForgotPasswordRequestDTO;
import com.tweetApp.DTO.LoginRequestDTO;
import com.tweetApp.DTO.LoginResponseDTO;
import com.tweetApp.DTO.RegisterDTO;
import com.tweetApp.DTO.ReplyDTO;
import com.tweetApp.DTO.ResetPasswordRequestDTO;
import com.tweetApp.DTO.ResetPasswordResponseDTO;
import com.tweetApp.DTO.UserDTO;
import com.tweetApp.DTO.UserTweetsDTO;
import com.tweetApp.DTO.VerifyUserResponseDTO;
import com.tweetApp.Model.Register;
import com.tweetApp.Model.Reply;
import com.tweetApp.Model.Tweet;
import com.tweetApp.Repository.RegisterRepository;
import com.tweetApp.Repository.ReplyRepository;
import com.tweetApp.Repository.TweetRepository;
import com.tweetApp.Repository.UserRepository;
import com.tweetApp.Service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userrepo;

	@Autowired
	private RegisterRepository registerrepo;

	@Autowired
	private TweetRepository tweetRepo;

	@Autowired
	ReplyRepository replyRepo;

	@Override
	public RegisterDTO register(RegisterDTO registerDTO) {
		if (checkUniqueEmail(registerDTO).getErrorMessage() != null) {
			return registerDTO;
		}
		Register register = convertDTOToEntity(registerDTO);
		userrepo.save(register);
		registerDTO.setSucessMessage("Registration Successful");

		return registerDTO;
	}

	private RegisterDTO checkUniqueEmail(RegisterDTO registerDTO) {
		if (!registerDTO.getEmail().isEmpty() && registerDTO.getEmail() != null) {
			Register register = userrepo.findByEmail(registerDTO.getEmail());
			if (register != null) {
				registerDTO.setErrorMessage("Entered E-mail/Login Id Already Exists");
			}
			Register loginIDCheck = userrepo.findByLoginId(registerDTO.getLoginId());
			if (loginIDCheck != null) {
				registerDTO.setErrorMessage("Entered Login Id Already Exists");
			}

		}
		return registerDTO;
	}

	private Register convertDTOToEntity(RegisterDTO registerDTO) {
		Register register = new Register();
		register.setLoginId(registerDTO.getLoginId());
		register.setFirstName(registerDTO.getFirstName());
		register.setLastName(registerDTO.getLastName());
		register.setContactNumber(registerDTO.getContactNumber());
		register.setEmail(registerDTO.getEmail());
		register.setPassword(registerDTO.getPassword());

		return register;
	}

	@Override
	public LoginResponseDTO signUp(LoginRequestDTO loginRequestDTO) {
		// TODO Auto-generated method stub
		LoginResponseDTO loginResponseDTO = new LoginResponseDTO();

		String loginId = loginRequestDTO.getLoginId();

		Register register = userrepo.findByLoginId(loginId);
		if (register != null) {
			if (!register.getPassword().equals(loginRequestDTO.getPassword())) {
				loginResponseDTO.setStatus(false);
				loginResponseDTO.setErrorMessage("Incorrect UserName/Password");
				return loginResponseDTO;

			}

			loginResponseDTO.setStatus(true);

			loginResponseDTO.setLoginId(register.getLoginId());
			loginResponseDTO.setEmail(register.getEmail());

			return loginResponseDTO;
		} else {
			loginResponseDTO.setStatus(false);
			loginResponseDTO.setErrorMessage("Incorrect UserName/Password");

		}

		return loginResponseDTO;
	}

	@Override
	public ResetPasswordResponseDTO resetpassword(ResetPasswordRequestDTO resetRequest) {
		// TODO Auto-generated method stub
		
		Register register = new Register();
		ResetPasswordResponseDTO resetPasswordResponseDTO = new ResetPasswordResponseDTO();

		register = userrepo.findByEmail(resetRequest.getEmailId());
		if (register != null && register.getPassword().equals(resetRequest.getOldpassword())) {
			register.setPassword(resetRequest.getNewpassword());
			userrepo.save(register);
			resetPasswordResponseDTO.setSuccessMessage("Password Updated Successfully");
		} else {
			resetPasswordResponseDTO.setErrorMessage("Entered Old Password is Incorrect");
		}

		return resetPasswordResponseDTO;
	}

	@Override
	public List<UserDTO> getAllUsers() {
		// TODO Auto-generated method stub

		List<UserDTO> userDTOList = new ArrayList<>();
		List<Register> register = registerrepo.findAll();
		register.parallelStream().forEach(user -> {
			UserDTO userDTO = new UserDTO();
			userDTO.setLoginId(user.getLoginId());
			userDTO.setFirstName(user.getFirstName());
			userDTO.setLastName(user.getLastName());
			userDTOList.add(userDTO);
		});

		return userDTOList;
	}

	@Override
	public List<UserTweetsDTO> getUsersTweet(String email) {
		List<UserTweetsDTO> userTweetsDTOList = new ArrayList<>();
		List<Tweet> tweetList = tweetRepo.findByEmail(email);
		tweetList.stream().forEach(tweet -> {
			UserTweetsDTO userTweetsDTO = new UserTweetsDTO();
//			userTweetsDTO.setTweetId(tweet.getId());
			userTweetsDTO.setTweetDesc(tweet.getTweetDescription());
			userTweetsDTO.setDate(tweet.getDate());
			List<Reply> replyList = replyRepo.findByTweetId(1);
			List<ReplyDTO> replyDTOList = new ArrayList<>();
			replyList.stream().forEach(reply -> {
				ReplyDTO replyDTO = new ReplyDTO();
//				replyDTO.setEmail(reply.getEmail());
				replyDTO.setReplyDesc(reply.getReplyDesc());
				replyDTO.setTweetId(reply.getTweetId());
//				replyDTO.setDate(reply.getDate());
				replyDTOList.add(replyDTO);
			});
			userTweetsDTO.setReplyDTOList(replyDTOList);
			userTweetsDTOList.add(userTweetsDTO);
		});

		return userTweetsDTOList;
	}

	@Override
	public VerifyUserResponseDTO verifyUser(String email) {
		// TODO Auto-generated method stub

		VerifyUserResponseDTO verifyUserResponseDTO = new VerifyUserResponseDTO();

		Register register = userrepo.findByEmail(email);
		if (register != null) {
			verifyUserResponseDTO.setEmail(email);	
			verifyUserResponseDTO.setSuccessMessage("userVerified Successfully");
		} else {
			verifyUserResponseDTO.setEmail(email);
			verifyUserResponseDTO.setErrorMessage("invalid user");
		}

		return verifyUserResponseDTO;
	}

	@Override
	public VerifyUserResponseDTO forgotPassword(ForgotPasswordRequestDTO forgotRequest) {
		
		VerifyUserResponseDTO resetPasswordResponse = new VerifyUserResponseDTO();

		Register register = userrepo.findByEmail(forgotRequest.getEmail());
		if (register != null) {
			register.setPassword(forgotRequest.getNewPassword());
			userrepo.save(register);
			resetPasswordResponse.setEmail(forgotRequest.getEmail());;	
			resetPasswordResponse.setSuccessMessage("password changed Successfully");
		} else {
			resetPasswordResponse.setEmail(forgotRequest.getEmail());
			resetPasswordResponse.setErrorMessage("unable to update password");
		}
		return resetPasswordResponse;
	}
}
