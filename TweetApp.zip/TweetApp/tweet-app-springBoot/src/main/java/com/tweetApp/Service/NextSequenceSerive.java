package com.tweetApp.Service;

public interface NextSequenceSerive {
	
	public int getNextSequence(String seqName);
}
