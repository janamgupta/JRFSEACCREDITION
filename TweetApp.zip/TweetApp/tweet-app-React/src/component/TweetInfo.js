import React from "react";
import { Container } from "react-bootstrap";
import NavBar from "./Nav";
import Reply from './Reply';
import axios from "axios";
import VerifiedUserIcon from "@material-ui/icons/VerifiedUser";
import ModeCommentOutlinedIcon from '@material-ui/icons/ModeCommentOutlined';
import FavoriteBorderRoundedIcon from '@material-ui/icons/FavoriteBorderRounded';
import FavoriteRoundedIcon from '@material-ui/icons/FavoriteRounded';
import Logo from '../assets/Usericon1.png';
import Logo2 from '../assets/Usericon2.png';
import Logo3 from '../assets/woman.png';

class TweetInfo extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            active: {
                main: '',
                viewTweet: 'active',
                viewUser: '',
                resetPass: '',
                myTweets: ''
            },
            isValidReply: false,
            isSuccess: true,
            replyTextDesc: '',
            errors:{
                reply: '', isSuccess: ''
            },
            replies: [],
            tweetInfo: this.props.location.state.detail,
            isLiked: this.props.location.state.isLiked,
            isLoggedIn: localStorage.getItem("isLoggedIn"),
        }
    }

    componentDidMount() {
        this.fetchReplies();
    }

    ValidationMessage(valid, message) {
        if (!valid) {
            return (
                <div className='error-msg'><span className='errorMsgText'>{message}</span></div>
            )
        }
        return null;
    }

    formatText(value, key) {
        if (key === "name") {
            var splitStr = value.toLowerCase().split(' ');
            for (var i = 0; i < splitStr.length; i++) {
                splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
            }
            return splitStr.join(' ');
        } else if (key === "date") {
            var date1 = new Date(value).getTime();
            var date2 = new Date().getTime();
            var msec = date2 - date1;
            var mins = Math.floor(msec / 60000);
            var hrs = Math.floor(mins / 60);
            var days = Math.floor(hrs / 24);
            var yrs = Math.floor(days / 365);

            if (mins < 60) {
                return mins + ' mins ago';
            } else if (mins > 60 && hrs <= 24) {
                if (hrs > 1)
                    return hrs + ' hours ago';
                else
                    return hrs + ' hour ago';
            } else {
                if (days > 1)
                    return days + ' days ago';
                else
                    return days + ' day ago';
            }
        } else if (key === "reply") {
            const repliesCount = value.length;
            return repliesCount;
        }
    }

    handleChange(target) {
        let name = target.name;
        let value = target.value;
        let isValidReply = true;
        let errors = this.state.errors;
        if (name === 'replyTextDesc') {
            if (value === '') {
                isValidReply = false;
                errors.reply = "please provide reply"
                this.setState({ isValidReply, [name]: value, errors})
            }else{
                this.setState({ isValidReply, [name]: value });
            }
        }else{
            this.setState({[name]: value, errors});
        }
    }

    fetchReplies() {
        axios.get('http://localhost:8092/api/v1.0/tweets/getReplies', { params: { tweetId: this.props.location.state.detail.tweetId } })
            .then((response) => {
                this.setState({ replies: response.data });
            }, (error) => {
                console.log(error);
            });
    }

    updateLikes() {
        if (this.state.isLoggedIn === "true") {
            if(this.state.isLiked === false){
                axios.get('http://localhost:8092/api/v1.0/tweets/like', { params: { tweetId: this.state.tweetInfo.tweetId } })
                .then((response) => {
                    if(response.data === "success"){
                        this.setState({isLiked: true});
                        const tweetInfo = this.state.tweetInfo
                        tweetInfo.likes = tweetInfo.likes + 1
                        this.setState({tweetInfo});
                    }
                });
            }
        } 
    }

    replyTweet() {
        if(this.state.isValidReply){
        axios.post('http://localhost:8092/api/v1.0/tweets/reply',
            {
                loginId: localStorage.getItem('username'),
                tweetId: this.state.tweetInfo.tweetId,
                replyDesc: this.state.replyTextDesc,
                replyTo: this.state.tweetInfo.loginId
        })
        .then((response) => {
            if(response.data === "Success"){
                console.log("tweet posted successfully");
                const tweetInfo = this.state.tweetInfo
                tweetInfo.replies = tweetInfo.replies + 1
                this.setState({tweetInfo});
                this.fetchReplies();
            } else {
                let isSuccess = false;
                let errors = this.state.errors;
                errors.isSuccess = "something went terribly wrong try after some time";
                this.setState({ isSuccess, errors });
            }
        }, (error) => {
            console.log(error);
        });
        } else {
            let errors = this.state.errors;
            errors.reply = "please provide reply"
            this.setState({errors})
        }
    }

    render() {
        return (
            <div>
                <NavBar active={this.state.active} />
                <Container className="mt-5">
                    <div className="row justify-content-center align-self-center">
                        <div className="card tweetcard mb-3" style={{ maxWidth: "540px" }}>
                            <div className="row no-gutters">
                                <div className="col-md-4">
                                    <img src={this.props.location.state.profile} className="avatar" />
                                </div>
                                <div className="col-md-7">
                                    <div className="card-body tweet-info">
                                        <div>
                                            <span><span>{this.formatText(this.state.tweetInfo.name, "name")} <VerifiedUserIcon className="verifiedUser" /></span><span> @{this.state.tweetInfo.loginId} . {this.formatText(this.state.tweetInfo.date, "date")}</span></span>
                                            <div>{this.state.tweetInfo.hashTag}</div>
                                            <p>{this.state.tweetInfo.tweetDesc}</p>
                                        </div>

                                        <div className="tweet-icons">
                                            <span><ModeCommentOutlinedIcon className="replyIcon" fontSize="small" color="action" />&nbsp;&nbsp;{`${this.state.tweetInfo.replies}  replies`}</span>&nbsp;&nbsp;
                                            <span>{this.state.isLiked?<FavoriteRoundedIcon color="error" fontSize="small"></FavoriteRoundedIcon>:<FavoriteBorderRoundedIcon className="favIcon" fontSize="small" color="action" onClick={() => this.updateLikes()}/>}&nbsp;&nbsp;{`${this.state.tweetInfo.likes}  likes`}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="collapse-1" class="bg-light p-2" data-parent="#myGroup">
                                <div className="d-flex flex-row align-items-start"><textarea className="form-control ml-1 shadow-none textarea" name="replyTextDesc" placeholder={`replying to @${this.state.tweetInfo.loginId}`} onChange={(e) => this.handleChange(e.target)}></textarea></div>
                                <div className="mt-2 text-right"><button className="btn btn-outline-primary btn-sm shadow-none" type="button" onClick={(e) => this.replyTweet(e)}>Post comment</button></div>
                                <div className="text-center">{this.state.isValidReply ? (this.state.isSuccess ? null : this.ValidationMessage(this.state.isSuccess, this.state.errors.isSuccess)) : this.ValidationMessage(this.state.isValidReply, this.state.errors.reply)}</div>
                            </div>
                        </div>
                    </div>
                    {this.state.replies.length !== 0 ?
                        this.state.replies.map((reply) => {
                            return <Reply replyInfo={reply} profile={this.props.location.state.profile} />
                        }) : null}
                </Container>
            </div>
        );
    }
}
export default TweetInfo;