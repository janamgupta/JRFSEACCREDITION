import React from "react";
import VerifiedUserIcon from "@material-ui/icons/VerifiedUser";
import Logo from '../assets/Usericon1.png';
import Logo2 from '../assets/Usericon2.png';
import Logo3 from '../assets/woman.png';
class Reply extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            reply : this.props.replyInfo
        }
    }

    formatText(value, key) {
        if (key === "name") {
            var splitStr = value.toLowerCase().split(' ');
            for (var i = 0; i < splitStr.length; i++) {
                splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
            }
            return splitStr.join(' ');
        } else if (key === "date") {
            var date1 = new Date(value).getTime();
            var date2 = new Date().getTime();
            var msec = date2 - date1;
            var mins = Math.floor(msec / 60000);
            var hrs = Math.floor(mins / 60);
            var days = Math.floor(hrs / 24);
            var yrs = Math.floor(days / 365);

            if (mins < 60) {
                return mins + ' mins ago';
            } else if (mins > 60 && hrs <= 24) {
                if (hrs > 1)
                    return hrs + ' hours ago';
                else
                    return hrs + ' hour ago';
            } else {
                if (days > 1)
                    return days + ' days ago';
                else
                    return days + ' day ago';
            }
        }
    }

    render() {
        return (
            <div class="row justify-content-center align-self-center">
                <div className="card replycard mb-3">
                    <div className="row no-gutters">
                        <div className="col-md-4">
                            <img src={this.props.profile} className="reply-avatar" />
                        </div>
                        <div className="col-md-7">
                            <div className="card-body reply-info">
                                <div>
                                    <span><span>{this.formatText(this.state.reply.name, "name")} <VerifiedUserIcon className="verifiedUser" /></span><span> @{this.state.reply.loginId} . {this.formatText(this.state.reply.date, "date")}</span></span>
                                    <div>replying to @{this.state.reply.replyTo}</div>
                                    <p>{this.state.reply.replyDesc}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Reply;