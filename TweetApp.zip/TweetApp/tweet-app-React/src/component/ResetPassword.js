import React from "react";
import { Button, Card, Col, Container, Form } from "react-bootstrap";
import NavBar from "./Nav";
import TwitterIcon from "@material-ui/icons/Twitter";
import axios from "axios";

class ResetPassword extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            email: '', emailValid: false,
            oldpassword: '', oldPasswordValid: false,
            newPassword: '', newPasswordValid: false,
            confirmPassword: '', confirmPasswordValid: false,
            formValid: false,
            validUser: true,
            active: {
                main: '',
                viewTweet: '',
                viewUser: '',
                resetPass: 'active',
                myTweets: ''
            },
            errors: {
                email: '', newPassword: '', validUser: '', confirmPassword: '', oldpassword: ''
            }
        };
        this.handleChange.bind(this);
    }
    componentDidMount() {
        let isLoggedIn = localStorage.getItem("isLoggedIn");
        if (isLoggedIn === 'false') {
            this.props.history.push('/login');
        }
    }

    ValidationMessage(valid, message) {
        if (!valid) {
            return (
                <div className='error-msg'><span className='errorMsgText'>{message}</span></div>
            )
        }
        return null;
    }

    resetPassword(e){
        e.preventDefault();
        axios.put('http://localhost:8092/api/v1.0/tweets/reset', {
            emailId: this.state.email,
            newpassword: this.state.newPassword,
            oldpassword: this.state.oldpassword
        })
            .then((response) => {
                if (response.data.errorMessage === null) {
                    localStorage.setItem('isLoggedIn', false);
                    localStorage.setItem('username', '');
                    localStorage.setItem('email', '');
                    this.props.history.push('/login');
                } else {
                    let errors = this.state.errors;
                    errors.validUser = response.data.errorMessage;
                    this.setState({validUser: false, errors})
                }
            }, (error) => {
                console.log(error);
            });
    }

    validateForm(){
        const { emailValid, oldPasswordValid, newPasswordValid, confirmPasswordValid } = this.state;
        this.setState({
            formValid: newPasswordValid && emailValid && confirmPasswordValid && oldPasswordValid
        })
    }

    handleChange(target) {
        this.setState({ validUser: true })
        const { name, value } = target;
        const emptyRegx = RegExp(/^(?!\s*$).+/i);
        var passRegex = RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/);
        var emailRegex = RegExp(/\S+@\S+\.\S+/);
        let errors = this.state.errors;
        if (name === 'email') {
            if (!emptyRegx.test(value)) {
                errors.email = 'user name is required';
            } else if (!emailRegex.test(value)) {
                errors.email = 'Invalid email' 
            } else {
                errors.email = '';
            }
            let emailValid = false;
            if (errors.email === '') {
                emailValid = true;
            }
            this.setState({ emailValid });
        } else if (name === 'oldpassword') {
                if (!emptyRegx.test(value)) {
                    errors.oldpassword = 'old password is required';
                } else {
                    errors.oldpassword = '';
                }
                let oldPasswordValid = false;
                if (errors.oldpassword === '') {
                    oldPasswordValid = true;
                }
                this.setState({ oldPasswordValid });
        } else if (name === 'newPassword') {
            if (!emptyRegx.test(value)) {
                errors.newPassword = 'password is required';
            } else if (!passRegex.test(value)) {
                errors.newPassword = 'password must contain a special character, uppercase letter, number and must be 8 characters long'
            }
            else {
                errors.newPassword = '';
            }
            let newPasswordValid = false;
            if (errors.newPassword === '') {
                newPasswordValid = true;
            }
            this.setState({ newPasswordValid });
        } else if (name === 'confirmPassword') {
            if (!emptyRegx.test(value)) {
                errors.confirmPassword = 'confirm password is required';
            } else if (value !== this.state.newPassword) {
                errors.confirmPassword = "password dosen't match";
            } else {
                errors.confirmPassword = '';
            }
            let confirmPasswordValid = false;
            if (errors.confirmPassword === '') {
                confirmPasswordValid = true;
            }
            this.setState({ confirmPasswordValid });
        }
        this.setState({ errors, [name]: value }, () => {
            this.validateForm();
        })
    }

    render() {
        return (
            <div>
                <NavBar active={this.state.active}/>
                <Container>
                    <Card variant="border-dark" className="logincard mx-auto">
                        <TwitterIcon className="login_twitterIcon mx-auto" />
                        <Card.Body className="text-dark">
                            <Form className="loginform">
                                <p className="h4 mb-4 mt-4">Reset Password</p>
                                <Form.Row>
                                    <Form.Group as={Col} md={12}>
                                        <input type="text" name="email" className="form-control" placeholder="Email" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} autoComplete="off" />
                                        {this.ValidationMessage(this.state.emailValid, this.state.errors.email)}
                                    </Form.Group>
                                </Form.Row>
                                <Form.Row>
                                    <Form.Group as={Col} md={12}>
                                        <input type="password" name="oldpassword" className="form-control" placeholder="Old Password" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} />
                                        {this.ValidationMessage(this.state.oldPasswordValid, this.state.errors.oldpassword)}
                                    </Form.Group>
                                </Form.Row>
                                <Form.Row>
                                    <Form.Group as={Col} md={12}>
                                        <input type="password" name="newPassword" className="form-control" placeholder="New Password" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} />
                                        {this.ValidationMessage(this.state.newPasswordValid, this.state.errors.newPassword)}
                                    </Form.Group>
                                </Form.Row>
                                <Form.Row>
                                    <Form.Group as={Col} md={12}>
                                        <input type="password" name="confirmPassword" className="form-control" placeholder="Confirm New Password" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} />
                                        {this.ValidationMessage(this.state.confirmPasswordValid, this.state.errors.confirmPassword)}
                                    </Form.Group>
                                </Form.Row>
                                <div className="text-center">
                                    <Button variant="outline-primary" className="my-4 signin" type="submit" disabled={!this.state.formValid} onClick={(e) => this.resetPassword(e)}> Reset </Button>
                                </div>
                                <h5 className="text-center">
                                    {this.ValidationMessage(this.state.validUser, this.state.errors.validUser)}
                                </h5>
                            </Form>

                        </Card.Body>
                    </Card>
                </Container>
            </div>
        );
    }
}

export default ResetPassword;