import { Link } from 'react-router-dom';
import { Nav, Navbar } from 'react-bootstrap';
import TwitterIcon from "@material-ui/icons/Twitter";
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import React from 'react';
class NavBar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoggedIn: localStorage.getItem('isLoggedIn'),
      userName: localStorage.getItem('username'),
      active: this.props.active
    };
  }

  logout(e) {
    localStorage.setItem('isLoggedIn', false);
    localStorage.setItem('username', '');
  }
  render() {
    return (
      <Navbar collapseOnSelect expand="lg" bg="white" className="routeNav">
        <Navbar.Brand><TwitterIcon className="navbar__twitterIcon" /></Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav" className="justify-content-between">
          <Nav className="mr-auto">
          <Nav.Item>
            <Link to="/" className={'nav-link'+this.props.active.main}>Home</Link>
          </Nav.Item>
          <Nav.Item>
            <Link to="/viewTweets" className={'nav-link'+this.props.active.viewTweet}>Tweets</Link>
          </Nav.Item>
          <Nav.Item>
            <Link to="/viewUsers" className={'nav-link'+this.props.active.viewUser}>Users</Link>
          </Nav.Item>
          {this.state.isLoggedIn === "true" ? <Nav.Item><Link to="/myTweets"  className={'nav-link'+this.props.active.myTweets+' loginNav'} >My Tweets</Link></Nav.Item> : null}
          {this.state.isLoggedIn === "true" ? <Nav.Item><Link to="/reset"  className={'nav-link'+this.props.active.resetPass+' loginNav'} >Reset Password</Link></Nav.Item> : null}
          </Nav>
          <Nav>
          {this.state.isLoggedIn === "true" ? <Navbar.Text className="username_text"><AccountCircleIcon></AccountCircleIcon>{  this.state.userName}</Navbar.Text> : <Nav.Item><Link to="/login" className="nav-link loginNav">Login</Link></Nav.Item>}
          {this.state.isLoggedIn === "true" ? <div onClick={(e) => this.logout()}><Nav.Item><Link to="/login" className="nav-link loginNav">Log out</Link></Nav.Item></div> : <Nav.Item><Link to="/register" className="nav-link registerNav">Register</Link></Nav.Item>}
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    );
  }
}

export default NavBar;