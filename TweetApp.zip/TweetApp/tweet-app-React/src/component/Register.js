import React from 'react';
import { Card, Form, Button, Container, Col } from 'react-bootstrap';
import TwitterIcon from "@material-ui/icons/Twitter";
import axios from 'axios';
class Register extends React.Component {
    constructor(props) {
        super();
        this.state = {
            firstName: '', firstNameValid: false,
            lastName: '', lastNameValid: false,
            email: '', emailValid: false,
            loginId: '', loginIdValid: false,
            password: '', passwordValid: false,
            confirmPassword: '', confirmPasswordValid: false,
            contactNumber: '', contactNumberValid: false,
            formValid: false,
            errors: {
                firstName: '', password: '', validUser: '', lastName: '', email: '', loginId: '', confirmPassword: '', contactNumber: ''
            }
        };
    }

    ValidationMessage(valid, message) {
        if (!valid) {
            return (
                <div className='error-msg'><span className='errorMsgText'>{message}</span></div>
            )
        }
        return null;
    }

    validateForm() {
        const { firstNameValid, passwordValid, lastNameValid, loginIdValid, emailValid, confirmPasswordValid, contactNumberValid } = this.state;
        this.setState({
            formValid: passwordValid && firstNameValid && lastNameValid && loginIdValid && emailValid && confirmPasswordValid && contactNumberValid
        })
    }

    userValidation(e) {
        e.preventDefault();
        axios.post('http://localhost:8092/api/v1.0/tweets/register', {
            loginId: this.state.loginId,
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            contactNumber: this.state.contactNumber,
            email: this.state.email,
            password: this.state.password,
            errorMessage: null,
            sucessMessage: null
        })
            .then((response) => {
                if (response.data.errorMessage === null) {
                    this.props.history.push("/login")
                } else {
                    let formValid = false;
                    let errors = this.state.errors;
                    errors.validUser = response.data.errorMessage;
                    this.setState({ formValid, errors });
                }
            }, (error) => {
                console.log(error);
            });
    }

    handleChange(target) {
        const { name, value } = target;
        let errors = this.state.errors;
        var nameRegex = RegExp(/^[A-Za-z]{2,30}$/);
        var emptyRegx = RegExp(/^(?!\s*$).+/i);
        var passRegex = RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/);
        var emailRegex = RegExp(/\S+@\S+\.\S+/);
        var numberRegex = RegExp(/^[0-9\b]{10}$/);
        var loginIdRegex = RegExp(/^\S*$/);
        if (name === 'firstName') {
            if (!emptyRegx.test(value)) {
                errors.firstName = 'First Name is required';
            } else if (!nameRegex.test(value)) {
                errors.firstName = 'First Name must be minimum two character long with no space.';
            } else {
                errors.firstName = '';
            }
            let firstNameValid = false;
            if (errors.firstName === '') {
                firstNameValid = true;
            }
            this.setState({ firstNameValid });
        } else if (name === 'password') {
            if (!emptyRegx.test(value)) {
                errors.password = 'password is required';
            } else if (!passRegex.test(value)) {
                errors.password = 'password must contain a special character, uppercase letter, number and must be 8 characters long'
            }
            else {
                errors.password = '';
            }
            let passwordValid = false;
            if (errors.password === '') {
                passwordValid = true;
            }
            this.setState({ passwordValid });
        } else if (name === 'confirmPassword') {
            if (!emptyRegx.test(value)) {
                errors.confirmPassword = 'password is required';
            } else if (value !== this.state.password) {
                errors.confirmPassword = 'password dosent match';
            } else {
                errors.confirmPassword = '';
            }
            let confirmPasswordValid = false;
            if (errors.confirmPassword === '') {
                confirmPasswordValid = true;
            }
            this.setState({ confirmPasswordValid });
        } else if (name === 'lastName') {
            if (!emptyRegx.test(value)) {
                errors.lastName = 'Last Name is required';
            } else if (!nameRegex.test(value)) {
                errors.lastName = 'Last Name must be minimum two character long with no space.';
            } else {
                errors.lastName = '';
            }
            let lastNameValid = false;
            if (errors.lastName === '') {
                lastNameValid = true;
            }
            this.setState({ lastNameValid });
        } else if (name === 'email') {
            if (!emptyRegx.test(value)) {
                errors.email = 'email is required';
            } else if (!emailRegex.test(value)) {
                errors.email = 'Invalid email'
            } else {
                errors.email = '';
            }
            let emailValid = false;
            if (errors.email === '') {
                emailValid = true;
            }
            this.setState({ emailValid });
        } else if (name === 'contactNumber') {
            if (!emptyRegx.test(value)) {
                errors.contactNumber = 'contact number is required';
            } else if (!numberRegex.test(value)) {
                errors.contactNumber = 'contact number should be numbers and 10 character long';
            } else {
                errors.contactNumber = '';
            }
            let contactNumberValid = false;
            if (errors.contactNumber === '') {
                contactNumberValid = true;
            }
            this.setState({ contactNumberValid });
        } else if (name === 'loginId') {
            if (!emptyRegx.test(value)) {
                errors.loginId = 'login id is required';
            } else if (!loginIdRegex.test(value)) {
                errors.loginId = 'login id must not contain spaces'
            } else {
                errors.loginId = '';
            }
            let loginIdValid = false;
            if (errors.loginId === '') {
                loginIdValid = true;
            }
            this.setState({ loginIdValid });
        }
        this.setState({ errors, [name]: value }, () => {
            this.validateForm();
        })
    }
    render() {
        return (
            <Container>
                <Card variant="border-dark" className="registercard mx-auto">
                    <TwitterIcon className="login_twitterIcon mx-auto" />
                    <Card.Body className="text-dark">
                        <Form className="loginform">
                            <p className="h4 mb-4 mt-4">Create your account</p>
                            <Form.Row>
                                <Form.Group as={Col} md={12}>
                                    <input type="text" name="firstName" className="form-control" placeholder="First Name" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} autoComplete="off" />
                                    {this.ValidationMessage(this.state.firstNameValid, this.state.errors.firstName)}
                                </Form.Group>
                            </Form.Row>
                            <Form.Row>
                                <Form.Group as={Col} md={12}>
                                    <input type="text" name="lastName" className="form-control" placeholder="Last Name" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} autoComplete="off" />
                                    {this.ValidationMessage(this.state.lastNameValid, this.state.errors.lastName)}
                                </Form.Group>
                            </Form.Row>
                            <Form.Row>
                                <Form.Group as={Col} md={12}>
                                    <input type="text" name="email" className="form-control" placeholder="Email" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} autoComplete="off" />
                                    {this.ValidationMessage(this.state.emailValid, this.state.errors.email)}
                                </Form.Group>
                            </Form.Row>
                            <Form.Row>
                                <Form.Group as={Col} md={12}>
                                    <input type="text" name="loginId" className="form-control" placeholder="Login ID" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} autoComplete="off" />
                                    {this.ValidationMessage(this.state.loginIdValid, this.state.errors.loginId)}
                                </Form.Group>
                            </Form.Row>
                            <Form.Row>
                                <Form.Group as={Col} md={12}>
                                    <input type="password" name="password" className="form-control" placeholder="Password" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} />
                                    {this.ValidationMessage(this.state.passwordValid, this.state.errors.password)}
                                </Form.Group>
                            </Form.Row>
                            <Form.Row>
                                <Form.Group as={Col} md={12}>
                                    <input type="password" name="confirmPassword" className="form-control" placeholder="Confirm Password" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} autoComplete="off" />
                                    {this.ValidationMessage(this.state.confirmPasswordValid, this.state.errors.confirmPassword)}
                                </Form.Group>
                            </Form.Row>
                            <Form.Row>
                                <Form.Group as={Col} md={12}>
                                    <input type="text" name="contactNumber" className="form-control" placeholder="Contact Number" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} autoComplete="off" />
                                    {this.ValidationMessage(this.state.contactNumberValid, this.state.errors.contactNumber)}
                                </Form.Group>
                            </Form.Row>
                            <div className="text-center">
                                <Button variant="outline-primary" className="my-4 signin" type="submit" onClick={(e) => this.userValidation(e)} disabled={!this.state.formValid}>Register</Button>
                            </div>
                            {this.ValidationMessage(this.state.formValid, this.state.errors.validUser)}
                        </Form>
                    </Card.Body>
                </Card>
            </Container>
        );
    }
}

export default Register;