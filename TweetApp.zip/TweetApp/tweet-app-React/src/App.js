import { Route, Switch } from 'react-router';
import Main from './component/Main.js';
import Register from './component/Register.js';
import Login from './component/Login.js';
import ViewTweet from './component/ViewTweet.js';
import ViewUsers from './component/ViewUsers';
import ResetPassword from './component/ResetPassword.js'
import Forgetpassword from './component/ForgotPassword.js'
import Error from './component/error.js'
import TweetInfo from './component/TweetInfo.js'
import MyTweet from './component/MyTweet.js'
import './App.css';

function App() {
  return (
    <main>
      <Switch>
        <Route path="/" component={Main} exact />
        <Route path="/register" component={Register} />
        <Route path="/login" component={Login} />
        <Route path="/viewTweets" component={ViewTweet} />
        <Route path="/viewUsers" component={ViewUsers} />
        <Route path="/reset" component={ResetPassword} />
        <Route path="/forgot" component={Forgetpassword} />
        <Route path="/tweetInfo" component={TweetInfo} />
        <Route path="/myTweets" component={MyTweet} />
        <Route component={Error} />
      </Switch>
    </main>
  );
}
export default App;
